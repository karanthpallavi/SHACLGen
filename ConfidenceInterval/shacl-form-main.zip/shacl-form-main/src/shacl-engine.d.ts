declare module 'shacl-engine'
declare module '@rdfjs/data-model'